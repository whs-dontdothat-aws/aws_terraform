import os, json, gzip, base64, boto3, logging
waf    = boto3.client('wafv2')
SCOPE  = os.getenv('SCOPE', 'REGIONAL')
IPSET_ID   = os.environ['IPSET_ID']
IPSET_NAME = os.environ['IPSET_NAME']
log = logging.getLogger(); log.setLevel(logging.INFO)

def lambda_handler(event, _):
    data = gzip.decompress(base64.b64decode(event['awslogs']['data']))
    logs = json.loads(data)

    ipset = waf.get_ip_set(Name=IPSET_NAME, Scope=SCOPE, Id=IPSET_ID)
    addrs = set(ipset['IPSet']['Addresses'])
    token = ipset['LockToken']
    changed = False

    for ev in logs['logEvents']:
        rec = json.loads(ev['message'])
        if rec.get('action') != 'BLOCK':
            continue                        

        cidr = f"{rec['httpRequest']['clientIp']}/32"
        if cidr in addrs:
            continue

        addrs.add(cidr); changed = True
        log.info(f"Queued {cidr}")

    if changed:
        waf.update_ip_set(
            Name=IPSET_NAME, Scope=SCOPE, Id=IPSET_ID,
            Addresses=list(addrs), LockToken=token)
        log.info("IPSet updated.")
