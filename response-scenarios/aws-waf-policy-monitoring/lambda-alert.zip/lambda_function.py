import json                  # JSON 데이터를 다루기 위한 모듈
import os                    # 환경변수(Webhook 주소 등)를 불러오기 위한 모듈
import urllib.request        # 인터넷으로 요청을 보내는 모듈 (여기선 Discord로 메시지를 보냄)
import base64                # AWS 로그가 base64 형식으로 인코딩되어 있기 때문에 디코딩에 사용
import gzip                  # 로그가 압축(gzip)되어 있어서 풀기 위한 모듈
from datetime import datetime, timezone, timedelta  # 시간 처리 (KST 변환용)

# 환경변수로부터 Discord Webhook 주소를 불러옴 (Lambda 환경 설정에 따로 저장해 둠)
WEBHOOK = os.environ['WEBHOOK']

# 메시지를 Discord로 보내는 함수
def post_to_discord(msg: str):
    # Discord에 보낼 메시지를 JSON 형식으로 구성
    data = json.dumps({"content": msg}).encode('utf-8')

    # 요청 정보를 담은 객체 생성
    req = urllib.request.Request(
        WEBHOOK,
        data=data,
        headers={
            "Content-Type": "application/json",  # 데이터 형식 지정
            "User-Agent": "aws-waf-discord-notifier"  # 요청 출처 식별용 문자열
        }
    )

    # 실제로 요청 보내기 (에러 발생 시 로그 출력)
    try:
        urllib.request.urlopen(req, timeout=5)
    except Exception as e:
        print(f"Discord 전송 오류: {e}")  # 전송 실패 시 콘솔에 에러 메시지 출력

# Lambda 함수의 시작 지점
def lambda_handler(event, context):
    # AWS WAF 로그는 압축(gzip) + 인코딩(base64) 형식으로 전달됨 → 먼저 디코딩
    compressed_payload = base64.b64decode(event['awslogs']['data'])

    # gzip 압축 해제
    decompressed_payload = gzip.decompress(compressed_payload)

    # JSON 형식으로 파싱 (문자열 → 파이썬 딕셔너리로 변환)
    log_data = json.loads(decompressed_payload)

    # 로그 안의 각 이벤트(공격 시도 등)를 하나씩 순회하며 처리
    for log_event in log_data['logEvents']:
        try:
            # 로그 메시지를 JSON 형식으로 파싱
            message = json.loads(log_event['message'])

            # 공격자가 보낸 요청 정보 가져오기
            http = message.get("httpRequest", {})

            # 어떤 룰(rule)에 의해 차단되었는지 정보 가져오기
            rule_info = message.get("ruleGroupList", [{}])[0].get("terminatingRule", {})

            # UTC 기준 타임스탬프를 KST(한국 시간)으로 변환
            ts_utc = datetime.fromtimestamp(message["timestamp"]/1000, tz=timezone.utc)
            ts_kst = ts_utc.astimezone(timezone(timedelta(hours=9)))

            # 디스코드로 보낼 메시지 구성
            content = (
                f"[WAF 공격 탐지]\n"
                f"공격 유형: {rule_info.get('ruleId', 'N/A')}\n"  # 탐지된 룰 ID (예: SQLi)
                f"발생 시각: {ts_kst.strftime('%Y-%m-%d %H:%M:%S')} (KST)\n"  # KST 기준 시간
                f"IP 주소: {http.get('clientIp', 'N/A')}\n"  # 요청 보낸 IP
                f"URI: {http.get('uri', 'N/A')}\n"           # 공격자가 요청한 URL 경로
                f"차단 여부: {rule_info.get('action', 'N/A')}\n"  # 차단(Block) 또는 허용(Allow)
                f"대상: {http.get('headers', [{}])[0].get('value', 'N/A')}"  # 헤더 정보 (보통 도메인)
            )

            # 위에서 만든 메시지를 Discord로 전송
            post_to_discord(content)

        except Exception as e:
            # 개별 이벤트 처리 중 오류 발생 시 출력 (전체 실패 방지)
            print(f"이벤트 처리 실패: {e}")
