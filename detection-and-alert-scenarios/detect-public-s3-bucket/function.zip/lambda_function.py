import json
import urllib3
import os

http = urllib3.PoolManager()
DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL", "")

def lambda_handler(event, context):
    try:
        detail = event.get("detail", {})
    except:
        return {"statusCode": 400, "body": "Invalid EventBridge message"}

    bucket_name = detail.get("resourceId", "Unknown")
    compliance = detail.get("newEvaluationResult", {}).get("complianceType", "UNKNOWN")
    annotation = detail.get("newEvaluationResult", {}).get("annotation", "No annotation")

    message = {
        "content": (
            f"S3 Public Access Detected\n"
            f"Bucket: `{bucket_name}`\n"
            f"Compliance Status: `{compliance}`\n"
            f"Reason: {annotation}"
        )
    }

    try:
        http.request(
            "POST",
            DISCORD_WEBHOOK_URL,
            body=json.dumps(message),
            headers={"Content-Type": "application/json"}
        )
    except:
        return {"statusCode": 500, "body": "Failed to send Discord message"}

    return {"statusCode": 200, "body": "Alert sent"}
