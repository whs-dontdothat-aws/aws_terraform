import json
import urllib.request
import os
from datetime import datetime, timezone, timedelta

def lambda_handler(event, context):
    # 환경변수에서 Discord 웹훅 URL 가져오기
    webhook_url = os.environ.get('DISCORD_WEBHOOK_URL')
    if not webhook_url:
        print("환경변수 DISCORD_WEBHOOK_URL이 설정되어 있지 않습니다.")
        return {'statusCode': 500, 'body': 'Webhook URL not set'}

    try:
        # SNS 메시지 추출 및 파싱
        sns_message_str = event['Records'][0]['Sns']['Message']
        sns_message = json.loads(sns_message_str)

        # 이벤트 상세 정보 추출
        detail = sns_message.get("detail", {})
        event_name = detail.get("eventName", "Unknown Event")
        event_time_utc = detail.get("eventTime")
        user_identity = detail.get("userIdentity", {})
        user_arn = user_identity.get("arn", "Unknown ARN")
        source_ip = detail.get("sourceIPAddress", "Unknown IP")
        aws_region = detail.get("awsRegion", "Unknown Region")
        account_id = detail.get("recipientAccountId", "Unknown Account")

        # UTC 시간을 한국 시간(KST)으로 변환
        if event_time_utc:
            try:
                utc_dt = datetime.strptime(event_time_utc, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                kst_dt = utc_dt.astimezone(timezone(timedelta(hours=9)))
                event_time_kst = kst_dt.strftime("%Y-%m-%d %H:%M:%S (KST)")
            except Exception as e:
                print("시간 변환 실패:", e)
                event_time_kst = event_time_utc + " (UTC)"
        else:
            event_time_kst = "Unknown Time"

    except Exception as e:
        # 메시지 파싱 실패 시 기본 값 설정
        print("SNS 메시지 파싱 실패:", e)
        event_name = "Unknown Event"
        event_time_kst = "Unknown Time"
        user_arn = "Unknown ARN"
        source_ip = "Unknown IP"
        aws_region = "Unknown Region"
        account_id = "Unknown Account"

    # Discord로 전송할 메시지 구성
    content = (
        f"**[ CloudTrail 이벤트 탐지 ]**\n"
        f"• 이벤트 이름: `{event_name}`\n"
        f"• 발생 시간: `{event_time_kst}`\n"
        f"• 사용자 ARN: `{user_arn}`\n"
        f"• 소스 IP: `{source_ip}`\n"
        f"• 리전: `{aws_region}`\n"
        f"• 계정 ID: `{account_id}`"
    )

    payload = json.dumps({"content": content}).encode("utf-8")

    # Discord 웹훅 요청 생성 및 전송
    req = urllib.request.Request(
        webhook_url,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Lambda)"
        }
    )

    try:
        with urllib.request.urlopen(req) as response:
            resp_body = response.read()
            print("Discord 응답:", resp_body)
    except Exception as e:
        # 전송 실패 시 오류 출력
        print("Discord 전송 실패:", e)
        return {'statusCode': 500, 'body': 'Discord notification failed'}

    return {'statusCode': 200, 'body': 'Notification sent successfully'}
