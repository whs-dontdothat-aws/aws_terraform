# -------------------------------
# 필요한 라이브러리 임포트
# -------------------------------

import json                                  # SNS 메시지(JSON 문자열)를 파싱하기 위해 사용
import urllib3                               # Discord Webhook으로 HTTP POST 요청을 보내기 위해 사용
import os                                    # Lambda 환경 변수를 읽기 위해 사용
from datetime import datetime, timezone, timedelta   # UTC 시각을 한국 표준시(KST)로 변환하기 위해 사용

# -------------------------------
# 환경 변수 및 기본 설정
# -------------------------------

# Discord Webhook URL을 Lambda 환경 변수에서 읽어옴
WEBHOOK_URL = os.environ["DISCORD_WEBHOOK_URL"]

# HTTP 연결을 재사용하기 위한 urllib3 커넥션 풀 생성
http = urllib3.PoolManager()

# 한국 표준시(KST, UTC+9) 타임존 객체 생성
KST = timezone(timedelta(hours=9), "KST")

# -------------------------------
# Lambda 핸들러 정의
# -------------------------------

def lambda_handler(event, context):
    """
    EventBridge → SNS → Lambda 구조에서 SNS 메시지를 파싱하여
    AMI 퍼블릭 또는 외부 계정 공유 이벤트를 탐지하고 Discord로 전송하는 함수
    """
    try:
        # SNS 메시지는 event["Records"][0]["Sns"]["Message"] 위치에 문자열로 저장됨
        sns_payload = event["Records"][0]["Sns"]["Message"]

        # 문자열이면 JSON 파싱, 아니면 그대로 사용
        ct_event = json.loads(sns_payload) if isinstance(sns_payload, str) else sns_payload

        # CloudTrail 이벤트 상세 정보 추출
        detail = ct_event.get("detail", {})

        # 이벤트 이름이 "ModifyImageAttribute"가 아니면 무시하고 종료
        if detail.get("eventName") != "ModifyImageAttribute":
            return

        # -------------------------------
        # 이벤트 필드 추출
        # -------------------------------

        # 이벤트 이름 (예: ModifyImageAttribute)
        event_name = detail.get("eventName", "Unknown")

        # 변경 대상 AMI 이미지 ID
        image_id = detail.get("requestParameters", {}).get("imageId", "Unknown")

        # 호출한 사용자(주체)의 ARN 정보
        user_arn = detail.get("userIdentity", {}).get("arn", "N/A")

        # 이벤트 발생 시각 (UTC ISO 포맷 문자열)
        utc_iso = ct_event.get("time")

        # UTC 시각을 KST(한국 시간)으로 변환하여 문자열로 저장
        if utc_iso:
            utc_dt = datetime.fromisoformat(utc_iso.replace("Z", "+00:00"))  # ISO 포맷 파싱
            kst_time = utc_dt.astimezone(KST).strftime("%Y-%m-%d %H:%M:%S KST")  # KST 문자열로 변환
        else:
            kst_time = "Unknown"

        # -------------------------------
        # 퍼블릭 공개 또는 외부 계정 공유 여부 확인
        # -------------------------------

        # launchPermission → add → items 배열 확인
        items = (detail.get("requestParameters", {})
                         .get("launchPermission", {})
                         .get("add", {})
                         .get("items", []))

        # 노출 대상 수집용 리스트
        exposure = []

        # 그룹이 "all"인 경우 → 퍼블릭 공개
        if any(it.get("group") == "all" for it in items):
            exposure.append("Public")

        # userId가 있는 경우 → 외부 계정 공유
        exposure += [it["userId"] for it in items if "userId" in it]

        # 노출 대상이 없으면 Unknown으로 설정
        exposure_str = ", ".join(exposure) if exposure else "Unknown"

        # -------------------------------
        # Discord 메시지 구성
        # -------------------------------

        message = (
            "**AMI 퍼블릭 / 외부 계정 공유 감지**\n"
            f"• 이벤트 이름 : `{event_name}`\n"
            f"• Image ID   : `{image_id}`\n"
            f"• 노출 대상  : {exposure_str}\n"
            f"• 호출 주체  : `{user_arn}`\n"
            f"• 발생 시각  : {kst_time}"
        )

        # -------------------------------
        # Discord Webhook POST 요청 전송
        # -------------------------------

        response = http.request(
            "POST",
            WEBHOOK_URL,  # Discord Webhook URL
            headers={
                "Content-Type": "application/json",      # JSON 형식으로 전송
                "User-Agent": "aws-lambda-discord/1.0"   # 일부 보안 필터 통과를 위한 User-Agent 지정
            },
            body=json.dumps({"content": message})        # 메시지 본문
        )

        # 성공적으로 전송된 경우 HTTP 상태코드와 응답 본문 반환
        return {
            "statusCode": response.status,               # 204 (No Content) 예상
            "body": response.data.decode("utf-8")
        }

    except Exception as exc:
        # 예외 발생 시 로그 출력 후 Lambda 함수 실패 처리
        print("Error:", exc)
        raise
