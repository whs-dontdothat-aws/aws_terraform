import json
import logging
import os
from datetime import datetime, timedelta
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

# Discord Webhook 환경 변수
HOOK_URL = os.environ['HOOK_URL']

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info("Received event: " + json.dumps(event))

    try:
        data = event['detail']

        # 사용자 구분
        user_type = data['userIdentity']['type']
        user = "Root" if user_type == "Root" else data['userIdentity'].get('userName', 'Unknown')

        # 로그인 시간 처리 (UTC → KST)
        login_time_utc = data['eventTime'][:19]
        login_time_kst = datetime.strptime(login_time_utc, '%Y-%m-%dT%H:%M:%S') + timedelta(hours=9)

        ip = data['sourceIPAddress']
        mfa = data['additionalEventData'].get('MFAUsed', 'Unknown')
        result = data['responseElements'].get('ConsoleLogin', 'Unknown')

        # 디스코드 메시지
        discord_message = {
            "content": f" **[{user_type}] AWS 콘솔 로그인 탐지**\n"
                       f" 사용자: {user}\n"
                       f" 시간: {login_time_kst.strftime('%Y-%m-%d %H:%M:%S')} (KST)\n"
                       f" IP: {ip}\n"
                       f" MFA 사용: {mfa}\n"
                       f" 로그인 결과: {result}"
        }

        # Discord Webhook 요청 (403 우회를 위한 User-Agent 추가)
        req = Request(
            HOOK_URL,
            data=json.dumps(discord_message).encode('utf-8'),
            headers={
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Lambda Discord Notification)'
            }
        )

        response = urlopen(req)
        response.read()
        logger.info("✅ Discord 메시지 전송 성공")

    except HTTPError as e:
        logger.error(f"❌ HTTP 오류: {e.code} - {e.reason}")
    except URLError as e:
        logger.error(f"❌ 연결 실패: {e.reason}")
    except Exception as e:
        logger.error(f"❌ 예외 발생: {str(e)}")
