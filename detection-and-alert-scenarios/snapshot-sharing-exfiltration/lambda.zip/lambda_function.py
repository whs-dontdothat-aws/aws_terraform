# lambda_function.zip 안에 있는 lambda_function.py
import json
import urllib3
import os
from datetime import datetime, timedelta

# HTTP 요청을 위한 객체 생성
http = urllib3.PoolManager()

# 환경 변수에서 Discord Webhook URL 불러오기
HOOK_URL = os.environ['DISCORD_WEBHOOK_URL'] # 위에서 정의한 key와 동일하게 작성

def lambda_handler(event, context):
    try:
        for record in event['Records']:
		        # SNS 메시지 파싱
            sns_message_str = record['Sns']['Message']
            outer_msg = json.loads(sns_message_str)
            
            # CloudTrail 이벤트의 실제 내용은 'detail' 내부에 존재
            detail = outer_msg.get('detail', {})

            # 이벤트 정보 추출
            event_name = detail.get('eventName', 'Unknown')
            user = detail.get('userIdentity', {}).get('userName', 'Unknown')
            user_arn = detail.get('userIdentity', {}).get('arn', 'Unknown')
            source_ip = detail.get('sourceIPAddress', 'Unknown')
            aws_region = outer_msg.get('region', 'Unknown')
            account_id = outer_msg.get('account', 'Unknown')
            event_time_utc = detail.get('eventTime', '')[:19]

            # 시간 변환 (UTC → KST)
            try:
                event_time_kst = datetime.strptime(event_time_utc, '%Y-%m-%dT%H:%M:%S') + timedelta(hours=9)
                time_str = event_time_kst.strftime('%Y-%m-%d %H:%M:%S') + " (KST)"
            except:
                time_str = 'Unknown'

            # Discord 메시지 구성
            discord_msg = {
                "content": f"**[ EBS 스냅샷 이벤트 감지됨 ]**\n"
                           f"• 이벤트 이름: `{event_name}`\n"
                           f"• 발생 시간: `{time_str}`\n"
                           f"• 사용자 ARN: `{user_arn}`\n"
                           f"• 소스 IP: `{source_ip}`\n"
                           f"• 리전: `{aws_region}`\n"
                           f"• 계정 ID: `{account_id}`"
            }

            # 전송
            encoded_msg = json.dumps(discord_msg).encode("utf-8")
            response = http.request(
                "POST",
                HOOK_URL,
                body=encoded_msg,
                headers={"Content-Type": "application/json"}
            )

            print(f"Discord 응답 상태: {response.status}")
        
        return {"statusCode": 200, "body": "Success"}

    except Exception as e:
        print(f"에러 발생: {str(e)}")
        return {"statusCode": 500, "body": "Error"}
